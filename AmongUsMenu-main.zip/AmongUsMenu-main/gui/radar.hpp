#pragma once

namespace Radar
{
	void Init();
	void Render();
}