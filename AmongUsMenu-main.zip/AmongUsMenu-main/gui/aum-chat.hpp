#pragma once

namespace ChatGui {
	void Init();
	void Render();
};