#pragma once

namespace Menu {
	void Init();
	void Render();
}