#pragma once

namespace SettingsTab {
	void Render();
}