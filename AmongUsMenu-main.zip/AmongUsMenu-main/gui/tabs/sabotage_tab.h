#pragma once

namespace SabotageTab {
	void Render();
}