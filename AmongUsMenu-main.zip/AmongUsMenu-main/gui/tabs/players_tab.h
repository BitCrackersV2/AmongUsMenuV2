#pragma once

namespace PlayersTab {
	void Render();
}