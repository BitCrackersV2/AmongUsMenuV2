#pragma once

namespace DebugTab {
	void Render();
}