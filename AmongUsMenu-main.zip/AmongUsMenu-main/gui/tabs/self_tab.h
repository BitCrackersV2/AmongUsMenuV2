#pragma once

namespace SelfTab {
	void Render();
}
