#pragma once

namespace TasksTab {
	void Render();
}