#pragma once

namespace DoorsTab {
	void Render();
}