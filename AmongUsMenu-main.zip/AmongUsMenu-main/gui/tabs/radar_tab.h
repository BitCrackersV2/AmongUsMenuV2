#pragma once

namespace RadarTab {
	void Render();
}