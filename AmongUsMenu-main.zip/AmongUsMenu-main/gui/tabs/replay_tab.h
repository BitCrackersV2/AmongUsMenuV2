#pragma once

namespace ReplayTab {
	void Render();
}