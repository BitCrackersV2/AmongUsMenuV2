#pragma once

namespace EspTab {
	void Render();
}