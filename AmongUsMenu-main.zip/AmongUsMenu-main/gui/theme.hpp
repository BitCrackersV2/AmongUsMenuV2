#pragma once

void ApplyTheme();