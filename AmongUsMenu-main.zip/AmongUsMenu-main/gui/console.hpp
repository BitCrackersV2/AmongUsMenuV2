#pragma once
#include <vector>

namespace ConsoleGui {
	void Init();
	void Render();
};