#pragma once
namespace Achievements {
    bool IsSupported();
    void UnlockAll();
}