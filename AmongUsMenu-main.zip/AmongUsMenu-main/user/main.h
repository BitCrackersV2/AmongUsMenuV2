#pragma once

extern HMODULE hModule;
extern HANDLE hUnloadEvent;

void Run(LPVOID lpParam);